# persistent_bottom_nav_bar example project

This is an example project which demonstrates the use of `persistent_bottom_nav_bar` package.

## Getting Started

Head over to the [official readme](https://github.com/BilalShahid13/PersistentBottomNavBar/blob/master/README.md) to get started.
